import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/telemetry.dart';
import '../widgets/common_widgets.dart';

class DashboardPage extends StatelessWidget {
  final TelemetrySnapshot data;
  final ValueChanged<int> onNavigate;

  const DashboardPage({super.key, required this.data, required this.onNavigate});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 20),
      children: [
        const Text('OVERVIEW', style: PulseStyles.kicker),
        const SizedBox(height: 4),
        const Text('Device Health',
            style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800)),
        const SizedBox(height: 12),
        PulseCard(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('DEVICE HEALTH SCORE', style: PulseStyles.kicker),
            const SizedBox(height: 4),
            Text(data.score?.toString() ?? '—',
                style:
                    const TextStyle(fontSize: 54, fontWeight: FontWeight.w900)),
            Text(
              data.score == null
                  ? 'Waiting for supported device metrics'
                  : '${data.score}/100 from observed metrics',
              style: const TextStyle(fontSize: 11, color: Color(0xFF9BA7AF)),
            ),
            const SizedBox(height: 10),
            const Text(
              'Score uses observed battery, storage, and memory only. Unsupported Android metrics are excluded.',
              style: TextStyle(fontSize: 11, color: Color(0xFF9BA7AF)),
            ),
            const SizedBox(height: 12),
            PulseHealthBar('Performance', data.performance),
            PulseHealthBar('Hardware', data.hardware),
            PulseHealthBar('Storage used', data.storage),
            PulseHealthBar('Battery charge', data.battery?.round()),
          ]),
        ),
        const SizedBox(height: 8),
        PulseCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const PulseHeader('PULSEOS DOCTOR', 'One-tap health check'),
              const SizedBox(height: 8),
              const Text(
                'Run a quick scan for battery, storage, memory, temperature, apps and permissions.',
                style: TextStyle(fontSize: 11, color: Color(0xFF9BA7AF)),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => _showDoctor(context, data),
                      icon: const Icon(Icons.medical_services_outlined, size: 18),
                      label: const Text('Fix My Phone'),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                _doctorSummaryText(data),
                style: const TextStyle(fontSize: 11, color: Color(0xFFD5DDE3)),
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        if (data.healthAlerts.isNotEmpty)
          PulseCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const PulseHeader('ACTIVE ALERTS', 'What is wrong?'),
                const SizedBox(height: 8),
                for (final alert in data.healthAlerts)
                  _alertExplanation(alert, data),
              ],
            ),
          ),
        const SizedBox(height: 8),
        PulseCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const PulseHeader('APP HEALTH', 'Android permission and background checks'),
              if (data.appHealth.isEmpty)
                const Text('No app health data is available yet.', style: TextStyle(fontSize: 11, color: Color(0xFF9BA7AF)))
              else ...[
                _healthRow('Usage stats', data.appHealth['usageStatsAllowed'] == true),
                _healthRow('Notifications', data.appHealth['notificationsEnabled'] == true),
                _healthRow('Storage access', data.appHealth['storageAccess'] == true),
                _healthRow('Battery saver', data.appHealth['batterySaver'] == true),
              ],
            ],
          ),
        ),
        const SizedBox(height: 8),
        if (data.cpuHistory.isNotEmpty || data.memoryHistory.isNotEmpty || data.temperatureHistory.isNotEmpty)
          PulseCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const PulseHeader('HISTORY', 'Recent signal trend'),
                const SizedBox(height: 8),
                if (data.cpuHistory.isNotEmpty)
                  PulseLiveGraph(
                    values: data.cpuHistory,
                    minY: 0,
                    maxY: 100,
                    color: const Color(0xFF7ED7FF),
                    label: 'CPU %',
                  ),
                if (data.memoryHistory.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  PulseLiveGraph(
                    values: data.memoryHistory,
                    minY: 0,
                    maxY: 100,
                    color: const Color(0xFFB7FFB0),
                    label: 'RAM %',
                  ),
                ],
                if (data.temperatureHistory.isNotEmpty) ...[
                  const SizedBox(height: 16),
                  PulseLiveGraph(
                    values: data.temperatureHistory,
                    minY: 20,
                    maxY: 70,
                    color: const Color(0xFFFFBE7A),
                    label: 'Temp °C',
                  ),
                ],
              ],
            ),
          ),
        const SizedBox(height: 8),
        const PulseHeader('QUICK ACTIONS', 'Common fixes and shortcuts'),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            _quickActionChip('Wi-Fi', Icons.wifi, () => _openSystemSetting(context, 'network')),
            _quickActionChip('Battery Saver', Icons.battery_saver, () => _openSystemSetting(context, 'battery')),
            _quickActionChip('Storage', Icons.storage, () => _openSystemSetting(context, 'storage')),
            _quickActionChip('Network', Icons.signal_cellular_4_bar, () => _openSystemSetting(context, 'network')),
            _quickActionChip('Permissions', Icons.lock_outline, () => _openSystemSetting(context, 'permissions')),
            _quickActionChip('Brightness', Icons.brightness_6, () => _openSystemSetting(context, 'display')),
          ],
        ),
        const SizedBox(height: 8),
        const Text('AVAILABLE TELEMETRY', style: PulseStyles.kicker),
        const SizedBox(height: 6),
        LayoutBuilder(
          builder: (context, constraints) {
            final columns = constraints.maxWidth >= 600 ? 3 : 2;
            return GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: columns,
              crossAxisSpacing: 7,
              mainAxisSpacing: 7,
              childAspectRatio: columns == 2 ? 1.1 : 1.45,
              children: [
                PulseMetric(
                    'BATTERY',
                    data.batteryLabel,
                    'Android BatteryManager',
                    () => _show(
                        context,
                        'Battery Details',
                        _detail([
                          'Charge',
                          data.batteryLabel,
                          'Status',
                          data.batteryStatus ?? 'Unavailable',
                          'Health',
                          _batteryHealthLabel(data.batteryHealth),
                          'Temperature',
                          _temperatureLabel(data.batteryTemperature),
                          'Voltage',
                          data.batteryVoltage == null ||
                                  data.batteryVoltage! < 0
                              ? 'Unavailable'
                              : '${data.batteryVoltage} mV',
                        ]))),
                PulseMetric(
                    'CPU',
                    data.cpuUsage == null
                        ? 'Sampling…'
                        : '${data.cpuUsage!.round()}%',
                    'Android Runtime',
                    () => _showCpuDetails(context, data)),
                PulseMetric('MEMORY', _formatBytes(data.availableMemory),
                    'Available RAM', () => _showMemoryDetails(context, data)),
                PulseMetric(
                    'TEMPERATURE',
                    data.batteryTemperature == null
                        ? 'Unavailable'
                        : _temperatureLabel(data.batteryTemperature),
                    data.temperatures.isEmpty
                        ? 'Battery sensor only'
                        : '${data.temperatures.length} sensors',
                    () => _showTemperatureDetails(context, data)),
                PulseMetric(
                    'DEVICE',
                    data.model ?? 'Unavailable',
                    data.androidApi == null
                        ? 'Android details unavailable'
                        : 'Android API ${data.androidApi}',
                    () => _showDeviceDetails(context, data)),
                PulseMetric(
                    'PROCESSES',
                    data.processes.isEmpty
                        ? _formatBytes(data.processMemory)
                        : '${data.processes.length} visible',
                    'Visible processor and memory status',
                    () => _showProcessDetails(context, data)),
              ],
            );
          },
        ),
        const SizedBox(height: 8),
        PulseCard(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const PulseHeader('TELEMETRY STATUS', 'What PulseOS can read'),
            const SizedBox(height: 8),
            _info('Battery charge', data.batteryLabel),
            _info(
                'System CPU / RAM',
                data.availableMemory == null
                    ? 'Unavailable on Android'
                    : '${_formatBytes(data.availableMemory)} available'),
            _info(
                'Thermal sensors', _temperatureLabel(data.batteryTemperature)),
            _info('Last capture', data.capturedLabel),
            if (data.error != null)
              Text(data.error!,
                  style:
                      const TextStyle(color: Color(0xFFE1B39A), fontSize: 11)),
          ]),
        ),
        PulseCard(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const PulseHeader('ATTENTION', 'Active Problems'),
            const SizedBox(height: 8),
            if (data.problems.isEmpty)
              const PulseProblemLine('No observed threshold breaches are reported',
                  good: true)
            else
              for (final problem in data.problems) PulseProblemLine(problem),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                  child: OutlinedButton(
                      onPressed: () => _unavailable(context, 'System fixes'),
                      child: const Text('REVIEW LIMITS'))),
              const SizedBox(width: 8),
              Expanded(
                  child: FilledButton(
                      onPressed: () => _show(
                          context,
                          'Safe Action',
                          const Text(
                              'PulseOS does not terminate processes or claim cleanup without an Android-supported API.')),
                      child: const Text('SAFE ACTION'))),
            ]),
          ]),
        ),
        PulseCard(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const PulseHeader('STORAGE', 'App storage only'),
            const SizedBox(height: 8),
            const Text(
                'Android restricts access to other apps and shared storage. Open Storage to scan PulseOS-owned files; device-wide figures are not claimed.',
                style: TextStyle(fontSize: 11, color: Color(0xFF9BA7AF))),
            const SizedBox(height: 8),
            OutlinedButton(
                onPressed: () => onNavigate(3),
                child: const Text('OPEN STORAGE HEALER')),
          ]),
        ),
        PulseCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const PulseHeader('PHONE HEALTH TIMELINE', 'Recent events'),
              const SizedBox(height: 6),
              ..._buildHealthTimeline(data).map((event) => Padding(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 54,
                          child: Text(
                            event['time']!,
                            style: const TextStyle(fontSize: 11, color: Color(0xFF9BA7AF)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(event['icon']!, style: const TextStyle(fontSize: 13)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            event['message']!,
                            style: const TextStyle(fontSize: 11, color: Color(0xFFDDE5EA)),
                          ),
                        ),
                      ],
                    ),
                  )),
            ],
          ),
        ),
      ],
    );
  }

  Widget _alertExplanation(String alert, TelemetrySnapshot data) {
    final explanation = _buildAlertExplanation(alert, data);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      margin: const EdgeInsets.only(bottom: 8),
      decoration: BoxDecoration(
        color: const Color(0xFF171F26),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFF263642)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(alert, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
          const SizedBox(height: 4),
          Text(explanation, style: const TextStyle(fontSize: 11, color: Color(0xFF9BA7AF))),
        ],
      ),
    );
  }

  Widget _quickActionChip(String label, IconData icon, VoidCallback onTap) {
    return ActionChip(
      avatar: Icon(icon, size: 16),
      label: Text(label),
      onPressed: onTap,
      backgroundColor: const Color(0xFF171F26),
      side: const BorderSide(color: Color(0xFF2A3740)),
      labelStyle: const TextStyle(fontSize: 11, color: Color(0xFFEEF4F7)),
    );
  }

  Widget _healthRow(String label, bool enabled) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Expanded(
              child: Text(label,
                  style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFF9BA7AF))),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: enabled
                    ? const Color(0xFF16372C)
                    : const Color(0xFF352C23),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                enabled ? 'OK' : 'CHECK',
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: enabled ? const Color(0xFF8FE3B5) : const Color(0xFFE7B587),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _info(String a, String b) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          Expanded(
              child: Text(a,
                  style: const TextStyle(fontSize: 11, color: Color(0xFF9BA7AF)))),
          Flexible(
              child: Text(b,
                  textAlign: TextAlign.end,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFFC4CCD0))))
        ]),
      );

  String _formatBytes(int? bytes) {
    if (bytes == null) return 'Unavailable';
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    if (bytes < 1024 * 1024 * 1024) {
      return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} MB';
    }
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} GB';
  }

  String _batteryHealthLabel(int? value) {
    switch (value) {
      case 2:
        return 'Good';
      case 3:
        return 'Overheat';
      case 4:
        return 'Dead';
      case 5:
        return 'Over voltage';
      case 6:
        return 'Failure';
      default:
        return 'Unavailable';
    }
  }

  String _temperatureLabel(double? value) =>
      value == null ? 'Unavailable' : '${value.toStringAsFixed(1)} °C';

  String _doctorSummaryText(TelemetrySnapshot data) {
    final issues = _doctorIssues(data);
    if (issues.isEmpty) {
      return 'No critical issues detected right now. Your device looks stable.';
    }
    return '${issues.length} issue${issues.length == 1 ? '' : 's'} found: ${issues.take(2).map((issue) => issue['title']).join(', ')}${issues.length > 2 ? '...' : ''}';
  }

  List<Map<String, String>> _doctorIssues(TelemetrySnapshot data) {
    final issues = <Map<String, String>>[];
    final storagePercent = data.storage ?? 0;
    final ramPercent = data.memoryAvailablePercent == null ? 0 : (100 - data.memoryAvailablePercent!);
    final batteryTemp = data.batteryTemperature ?? 0;

    if (storagePercent >= 75) {
      issues.add({'title': 'Storage almost full', 'detail': 'Storage is at $storagePercent% used and may be causing slowdowns.'});
    }
    if (ramPercent >= 70) {
      issues.add({'title': 'High memory usage', 'detail': '$ramPercent% RAM is currently in use. Review recent apps and background activity.'});
    }
    if (batteryTemp >= 40) {
      issues.add({'title': 'Temperature elevated', 'detail': 'The device temperature is ${batteryTemp.toStringAsFixed(1)}°C and should be monitored.'});
    }
    if (data.battery != null && data.battery! < 20) {
      issues.add({'title': 'Battery low', 'detail': 'Battery is ${data.batteryLabel} and may trigger power-saving behavior.'});
    }
    return issues;
  }

  List<Map<String, String>> _buildHealthTimeline(TelemetrySnapshot data) {
    if (data.recentEvents.isNotEmpty) {
      return data.recentEvents;
    }
    return data.buildRecentEventTimeline();
  }

  String _buildAlertExplanation(String alert, TelemetrySnapshot data) {
    if (alert.toLowerCase().contains('battery')) {
      return 'Battery is currently at ${data.batteryLabel}. Short periods are normal, but consistently low charge or heat can reduce performance and battery life.';
    }
    if (alert.toLowerCase().contains('memory') || alert.toLowerCase().contains('ram')) {
      final used = data.memoryAvailablePercent == null ? 0 : (100 - data.memoryAvailablePercent!);
      return 'High memory usage: $used% of RAM is currently being used. Review background apps and recent tasks to reduce pressure.';
    }
    if (alert.toLowerCase().contains('storage')) {
      final percent = data.storage ?? 0;
      return 'Storage is $percent% full. This can make the phone feel slower and limit space for updates, media, and app cache.';
    }
    if (alert.toLowerCase().contains('temperature') || alert.toLowerCase().contains('heat')) {
      return 'The device temperature is ${_temperatureLabel(data.batteryTemperature)}. High temperature usually means heavy work, background tasks, or a charging-related thermal spike.';
    }
    if (alert.toLowerCase().contains('network')) {
      return 'The network signal or connectivity is unstable. PulseOS is flagging a potential latency or reachability issue that may slow background activity.';
    }
    return 'PulseOS is highlighting this issue because the current phone state appears outside the normal healthy range for regular use.';
  }

  Future<void> _openSystemSetting(BuildContext context, String setting) async {
    try {
      await const MethodChannel('pulseos/device').invokeMethod('openPhoneSetting', {'setting': setting});
    } catch (_) {
      if (context.mounted) {
        _show(context, 'System screen', const Text('Android did not expose this system screen directly, so the setting could not be opened automatically.'));
      }
    }
  }

  void _showDoctor(BuildContext context, TelemetrySnapshot data) {
    final issues = _doctorIssues(data);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF11171D),
        title: const Text('PulseOS Doctor'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                issues.isEmpty
                    ? 'No major issues detected. Your phone is running in a healthy state.'
                    : 'Device Health: ${(100 - (issues.length * 12)).clamp(0, 100)}/100',
                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 12),
              if (issues.isEmpty)
                const Text('No critical device signals are active right now.')
              else
                ...issues.map((issue) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(issue['title']!, style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 2),
                      Text(issue['detail']!, style: const TextStyle(fontSize: 11, color: Color(0xFF9BA7AF))),
                    ],
                  ),
                )),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('CLOSE'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(context);
              if (issues.any((issue) => issue['title']!.contains('Storage'))) {
                _openSystemSetting(context, 'storage');
              } else if (issues.any((issue) => issue['title']!.contains('Battery'))) {
                _openSystemSetting(context, 'battery');
              } else {
                _openSystemSetting(context, 'network');
              }
            },
            child: const Text('FIX NOW'),
          ),
        ],
      ),
    );
  }

  void _show(BuildContext context, String title, Widget body) =>
      showModalBottomSheet(
          context: context,
          backgroundColor: const Color(0xFF10161C),
          showDragHandle: true,
          isScrollControlled: true,
          builder: (_) => Padding(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 24),
              child: SingleChildScrollView(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title,
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 12),
                    body,
                    const SizedBox(height: 8),
                  ]))));

  void _unavailable(BuildContext context, String metric) => _show(
      context,
      metric,
      const Text(
        'This platform does not expose this data to PulseOS. The value is marked unavailable instead of being simulated.',
        style: TextStyle(fontSize: 12, color: Color(0xFFB9C5CB)),
      ));

  Widget _detail(List<String> pairs) => GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 2.8,
            crossAxisSpacing: 7,
            mainAxisSpacing: 7),
        itemCount: pairs.length ~/ 2,
        itemBuilder: (context, index) => Container(
            padding: const EdgeInsets.all(9),
            decoration: BoxDecoration(
                color: const Color(0xFF0C1217),
                border: Border.all(color: const Color(0xFF20272E)),
                borderRadius: BorderRadius.circular(8)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(pairs[index * 2],
                  style: const TextStyle(fontSize: 9, color: Color(0xFF9BA7AF))),
              Text(pairs[index * 2 + 1],
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style:
                      const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            ])),
      );

  void _showCpuDetails(BuildContext context, TelemetrySnapshot data) {
    _show(
      context,
      'CPU Details',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (data.cpuHistory.isNotEmpty)
            PulseLiveGraph(
              values: data.cpuHistory,
              minY: 0,
              maxY: 100,
              color: const Color(0xFF7ED7FF),
              label: 'Recent CPU load',
            ),
          const SizedBox(height: 12),
          _detail([
            'Current', data.cpuUsage == null ? 'Unavailable' : '${data.cpuUsage!.round()}%',
            'Cores', data.cpuCores == null ? 'Unavailable' : '${data.cpuCores} cores',
            'Process memory', _formatBytes(data.processMemory),
            'Visible processes', data.processes.isEmpty ? 'Unavailable' : '${data.processes.length}',
          ]),
        ],
      ),
    );
  }

  void _showMemoryDetails(BuildContext context, TelemetrySnapshot data) {
    final total = data.totalMemory;
    final available = data.availableMemory;
    _show(
      context,
      'Memory Details',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (data.memoryHistory.isNotEmpty)
            PulseLiveGraph(
              values: data.memoryHistory,
              minY: 0,
              maxY: 100,
              color: const Color(0xFFB7FFB0),
              label: 'RAM usage',
            ),
          const SizedBox(height: 12),
          _detail([
            'Total', total == null ? 'Unavailable' : _formatBytes(total),
            'Available', available == null ? 'Unavailable' : _formatBytes(available),
            'Used', total == null || available == null ? 'Unavailable' : _formatBytes((total - available).clamp(0, total)),
            'Used %', total == null || available == null ? 'Unavailable' : '${((total - available) * 100 / total).round()}%',
          ]),
        ],
      ),
    );
  }

  void _showTemperatureDetails(BuildContext context, TelemetrySnapshot data) {
    _show(
      context,
      'Temperature Details',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (data.temperatureHistory.isNotEmpty)
            PulseLiveGraph(
              values: data.temperatureHistory,
              minY: 20,
              maxY: 70,
              color: const Color(0xFFFFBE7A),
              label: 'Thermal trend',
            ),
          const SizedBox(height: 12),
          _detail([
            'Battery', _temperatureLabel(data.batteryTemperature),
            'Sensors', data.temperatures.isEmpty ? 'Only battery sensor' : '${data.temperatures.length} sensors',
            'Status', data.batteryTemperature == null ? 'Unavailable' : (data.batteryTemperature! > 45 ? 'High' : 'Normal'),
            'Voltage', data.batteryVoltage == null || data.batteryVoltage! < 0 ? 'Unavailable' : '${data.batteryVoltage} mV',
          ]),
        ],
      ),
    );
  }

  void _showDeviceDetails(BuildContext context, TelemetrySnapshot data) {
    _show(
      context,
      'Device Details',
      _detail([
        'Model', data.model ?? 'Unavailable',
        'Brand', data.brand ?? 'Unavailable',
        'Android', data.androidVersion ?? 'Unavailable',
        'API', data.androidApi == null ? 'Unavailable' : 'API ${data.androidApi}',
        'Security', data.securityPatch ?? 'Unavailable',
        'Build', data.buildNumber ?? 'Unavailable',
        'Architecture', data.architecture ?? 'Unavailable',
        'Storage', data.totalStorage == null ? 'Unavailable' : _formatBytes(data.totalStorage),
      ]),
    );
  }

  void _showProcessDetails(BuildContext context, TelemetrySnapshot data) {
    _show(
      context,
      'Process Details',
      Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (data.processes.isNotEmpty) ...[
            const Text('Visible processes', style: TextStyle(fontSize: 11, color: Color(0xFF9BA7AF))),
            const SizedBox(height: 8),
            ...data.processes.take(5).map((process) => Container(
              margin: const EdgeInsets.only(bottom: 6),
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: const Color(0xFF0C1217),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: const Color(0xFF20272E)),
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      '${process['name'] ?? 'Process'}',
                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700),
                    ),
                  ),
                  Text(
                    process['cpu'] == null ? '—' : '${(process['cpu'] as num).toStringAsFixed(1)}%',
                    style: const TextStyle(fontSize: 11, color: Color(0xFF9BA7AF)),
                  ),
                ],
              ),
            )),
          ] else
            const Text('Android did not return process details for this session.', style: TextStyle(fontSize: 11, color: Color(0xFF9BA7AF))),
        ],
      ),
    );
  }
}
